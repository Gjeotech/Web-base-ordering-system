<?php
session_start();

include("dbcon/dbcon.php");

$Order_date = date("D:m:y h:i a");

if(isset($_POST["send"])){
$uemail = $_POST['em'];
$prod_name = $_POST['pn'];
$weigth  = $_POST['wt'];
$from  =    $_POST['loc'];
$to  =     $_POST['opt2'];
$trans_mode = $_POST['trmode'];


//Tax added value to US and UK detinations
$taxrate = 10;
$TOTAL_TAX = $from/100*$taxrate ; 

//Total caharge model
$total_caharge = $trans_mode+$from+$weigth+$TOTAL_TAX;

//insert model
$insert ="INSERT INTO `oder_products`(`user_email`,`product_name`, `Destination_cost`, `To`, `mode_cost`, `weight_kg`,`taxation_fee`, `total_charge`, `Order_date`) VALUES ('$uemail','$prod_name','$from','$to','$trans_mode','$weigth','$TOTAL_TAX',$total_caharge,'$Order_date')";

$run = mysqli_query($link,$insert);
if($run){
echo "<div style='background-color:navy;color:white;font-weight:bold'>Order Posted Successfully;Check your Order Below</div>" ;
	
}else{

echo"<div style='background-color:navy;color:white;font-weight:bold'>Order Unsuccessful</div>" ;
}

// Setup mail contents
$mailfrom = 'info@churchofchristptiroad.com';
$mailto = $uemail; 
$headers = 'info@churchofchristptiroad.com';
$subject = "payment order receipt";

// Additional headers 
$headers .= 'From: '.$mailfrom. "\r\n"; 
$headers .= 'Cc: ifeanyionyeacholem@yahoo.co.uk' . "\r\n"; 
$headers .= 'Bcc: femitaiwo@initsng.com' . "\r\n"; 
 
##// Get HTML contents from file 
$htmlContent = " 

    <div class='w3-welcome-grids w3-welcome-bottom'>
	<div style='background-color:#000066;width:40%;height:300px;overflow-x:auto;color:white'>
        <h3>Thanks; your order is on the way... </h3> 
		<p>Note that BY Air, Your order will arived in<br>
		Nigeria in two days time after shipment.</p>
		<p>While Transportation By Sea however, Takes <br>
        10 times longer than by Air.</p>
   <h3>But be rest assure that your order is safe with us.</h3>
<p>Thanks for your patronage</p>

You can visit our website <a href='http://www.churchofchristptiroad.com'>by clicking</a>   
		
</div>
</div>";		
//mail content setptup Ends here.
	
 // Send email triger 
if(@mail($mailfrom,$mailto,$subject,$headers,$htmlContent)){ 
    echo 'Email Alert has been sent successfully.'; 
}else{ 
   echo 'Email sending failed.'; 
}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>SuperFreighters| Home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Freightage Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<!--web-fonts-->
<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
<!--//web-fonts-->
<!--//fonts-->
</head>
<body>

<div class="banner-w3layouts" id="home">
		<!--Top-Bar-->
	<div class="header">
		<nav class="navbar navbar-default">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1 ><a  href="index.php" style='border-radius:15px;border:3px dotted navy'>SuperFreighters</a></h1>
					</div>
					
					<!-- navbar-header -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a class="hvr-underline-from-center active scroll" href="index.html">Home</a></li>
							<li><a href="#features" class="hvr-underline-from-center scroll">Features</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>	
				</nav>
	
	</div>
	
	<!-- //modal --> 
	<!-- modal -->
	<div class="modal about-modal w3-agileits fade" id="myModal3" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				 
				</div> <!-- //login-page -->
			</div>
		</div>
	<!-- //modal --> 
<!--banner-->
		<!--Slider-->
			<div class="w3l_banner_info">
				<div class="col-md-7 slider">
					<div class="callbacks_container">
								<ul class="rslides" id="slider3">
									<li>
										<div class="slider_banner_info">
											 <h4>Comfortable Payment</h4>
											<p>Quality transport ready to go</p>
										</div>

									</li>
									<li>
										<div class="slider_banner_info">
											<h4>Delivery unlimited.</h4>
											<p>Discover a better way of transport</p>
										</div>

									</li>
									<li>
										<div class="slider_banner_info">
											<h4>Comfortable Payment</h4>
											<p>Quality transport ready to go</p>
										</div>

									</li>
									<li>
										<div class="slider_banner_info">
											<h4>Delivery unlimited.</h4>
											<p>Discover a better way of transport</p>
										</div>

									</li>
								</ul>
					</div>
				</div>

				<div class="col-md-5 banner-form-agileinfo">

				<h2 style="color:black">PLACE AN ORDER</h2>
					<form action="#" method="post">
						
						<input type="text" class="email" name="em" placeholder="Enter Your Email" required=""/>
						<input type="text" class="email" name="pn" placeholder="Enter Product Name" required=""/>
						
						<input type="text" class="email" name="wt" placeholder="Enter Product Weight" required=""/>
						
						<select class="form-control option-w3ls" name="opt1">
								<option>From Location</option>
								<input type="checkbox" Value="1500" name="loc"><b style="color:white">US</b>
								<input type="checkbox" Value="800" name="loc"><b style="color:white">UK</b>
							</select>
						<select class="form-control option-w3ls" name="opt2">
								<option>Transport To</option>
								<option value="Nigeria">NIGERIA</option>
							</select>
						<select class="form-control option-w3ls">
								<option>Choose Mode of Transportation </option>
								<input type="checkbox" Value="50000" name="trmode"><b style="color:white">Air</b>
								<input type="checkbox" Value="15000" name="trmode"><b style="color:white">Sea</b>
							</select>
								<!--<p style="color:white">How many Kilogram?</p>
							<input type="number"  name="kg" placeholder="Enter Kilogram" required=""/>-->
							
						<input type="submit" name="send" class="hvr-shutter-in-vertical" value="Place Order">
					
					</form>
					

</div>
		</div>
		<!--paymet method-->
	
	  
	  <script>
	function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'sk_test_d948db60cbc0b3435d469b149f0dd659d079fdbd',
       amount: <?php echo $total_caharge; ?>, 
      
      callback: function(response){
          alert('success. transaction ref is ' + response.reference);
          window.location='index.php';
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
 </script>	
 

			<!--//Slider-->
			<div class="clearfix"></div>
						</div>
		
<!--//banner-->

<!-- welcome --><br><center>
<div style="background-color:#000066;width:40%;height:300px;overflow-x:auto;color:white">
<?php

if(isset($_POST["send"])){
	
$Destn = $from;
  if($Destn == 800){
	  $Destn = 'UK';
  }else if($Destn == 1500){
	  $Destn = 'US';
  }
  
  
  //modify mode of transportation
   $trsn_md = $trans_mode;
  if($trsn_md ==15000){
	  $trsn_md = 'By Sea';
	  
  }else if($trsn_md ==50000){
	  $trsn_md = 'By Air';
  }
  
echo"
<hr>
 <h2>Your Order:</h2><br>
 <p>User Email:</P>
 $uemail<hr>
 <p>Product Name:</p>
 $prod_name<hr>
 <p>From:</p>
 $Destn<hr>
 <p>To:</p>
 $to<hr>
 <p>Transport Mode:</p>
 $trsn_md<hr>
 <p>Product Weight:</p>
 $weigth &#13199 <hr>
<p>Tax add:</p>
  $TOTAL_TAX &#37<hr>
<p>Total Export Charges:</p>
 &#8358;".number_format($total_caharge,2)."<hr>
<p>Ordered Date:</p>
 $Order_date<hr>
";
}
?>

<div class="pull-top">
<script src="https://js.paystack.co/v1/inline.js">
</script>

<a href="../interview/payment/payment.php" onclick="payWithPaystack()" class="btn btn-success">Pay With Card</a>
</div>
</div>
</center>
	<div class="features" id="features">
		<div class="container">
			<h2 class="title-w3">Amazing features</h2>
		    <div class="w3-agile-top-info">	
			<div class="w3-welcome-grids">
				<div class="col-md-7 w3-welcome-left">
					<h5>WE OFFER QUICK & POWERFUL SOLUTION FOR TRANSPORT</h5>
					
				</div>
				<div class="col-md-5 w3ls-welcome-img1">
					<img src="images/work8.jpg" alt="" />
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="w3-welcome-grids w3-welcome-bottom">
				<div class="col-md-5 w3ls-welcome-img1 w3ls-welcome-img2">
					<img src="images/6.jpg" alt="" />
				</div>
				<div class="col-md-7 w3-welcome-left">
					<h5>CARGO SHIPPING AVAILABLE AT GOOD DISCOUNTS</h5>
					
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
</div>
	<!-- //welcome -->
<!-- Stats -->
	<div class="jarallax  stats-agileits" id="stats">
		<div class="stats-info agileits w3layouts">
			<div class="col-md-3 agileits w3layouts col-sm-3 stats-grid stats-grid-1">
				<div class="numscroller agileits-w3layouts" data-slno='1' data-min='0' data-max='15' data-delay='3' data-increment="2">15</div>
				<div class="stat-info-w3ls">
					<h4 class="agileits w3layouts"><span>years</span> of growing business</h4>
				</div>
			</div>
			<div class="col-md-3 col-sm-3 agileits w3layouts stats-grid stats-grid-2">
				<div class="numscroller agileits-w3layouts" data-slno='1' data-min='0' data-max='2012' data-delay='3' data-increment="2">2012</div>
				<div class="stat-info-w3ls">
					<h4 class="agileits w3layouts"><span>Satisfied</span> clients</h4>
				</div>
			</div>
			<div class="col-md-3 col-sm-3 stats-grid agileits w3layouts stats-grid-3">
				<div class="numscroller agileits-w3layouts" data-slno='1' data-min='0' data-max='500' data-delay='3' data-increment="2">500</div>
				<div class="stat-info-w3ls">
					<h4 class="agileits w3layouts"><span>Drivers</span> nationwide</h4>
				</div>
			</div>
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-4 agileits w3layouts">
				<div class="numscroller agileits-w3layouts" data-slno='1' data-min='0' data-max='4535' data-delay='3' data-increment="2">41535</div>
				<div class="stat-info-w3ls">
					<h4 class="agileits w3layouts"><span>Loads</span> per year</h4>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>

	</div>
	<!-- //Stats -->

<!--team-->

		<!-- //gallery --> 	

	<div class="copy">
		<p>© 2021 SuperFreighters, All Rights Reserved | @brandykoke@gmail.com</a> </p>
	</div>
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- jarallax-js -->
			<script src="js/jarallax.js"></script>
			<script src="js/SmoothScroll.min.js"></script>
			<script type="text/javascript">
				/* init Jarallax */
				$('.jarallax').jarallax({
					speed: 0.5,
					imgWidth: 1366,
					imgHeight: 768
				})
			</script>
<!-- //jarallax-js -->
					<!--banner Slider starts Here-->
						<script src="js/responsiveslides.min.js"></script>
							<script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider3").responsiveSlides({
									auto: true,
									pager:true,
									nav:false,
									speed: 500,
									namespace: "callbacks",
									before: function () {
									  $('.events').append("<li>before event fired.</li>");
									},
									after: function () {
									  $('.events').append("<li>after event fired.</li>");
									}
								  });
							
								});
							 </script>

							<!--banner Slider starts Here-->


<!--light-box-files -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.chocolat.js"></script>
<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
<!--//light-box-files -->
		<script type="text/javascript">
		$(function() {
			$('.gallery a').Chocolat();
		});
		</script>
<!-- //js -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!--//footer-section-->
<!-- Starts-Number-Scroller-Animation-JavaScript -->		
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- //Starts-Number-Scroller-Animation-JavaScript -->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->


<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>
</html>