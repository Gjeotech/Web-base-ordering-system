<?php


include("dbcon/dbcon.php");





?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>SuperFreighters| Home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Freightage Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<!--web-fonts-->
<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
<!--//web-fonts-->
<!--//fonts-->
</head>
<body>
<div class="features" id="features">
		<div class="container">
			<h2 class="title-w3">CheckOut</h2>
		    <div class="w3-agile-top-info">	
			
			<div class="w3-welcome-grids w3-welcome-bottom">
			 <form method="get">
 <?php
 
  $read = "SELECT * FROM oder_products ";
  $asses = mysqli_query($link,$read);
  while($row = mysqli_fetch_array($asses)){
  $id = $row['id'];
  $email = $row['user_email'];
  $prodt_name =$row['product_name'];
  $destn_cost =$row['Destination_cost'];
  $to_loc = (strtolower($row['To']));
  $mod_cost =$row['mode_cost'];
  $weight =$row['weight_kg'];
  $tax_add =$row['taxation_fee'];
  $total_chg =$row['total_charge'];
  $total_chg2 +=$row['total_charge'];
  $date = $row['Order_date'];
  
  //modify destination 
  $Destn = $destn_cost;
  if($destn_cost ==800){
	  $Destn = 'UK';
  }else if($Destn == 1500){
	  $Destn = 'US';
  }
  
  
  //modify mode of transportation
   $trsn_md = $mod_cost;
  if($trsn_md ==15000){
	  $trsn_md = 'By Sea';
	  
  }else if($trsn_md ==50000){
	  $trsn_md = 'By Air';
  }
?>

</form>

						
				<div class="clearfix"> </div>
				
				
			</div>
		</div>
	</div>
</div>
</BODY>
</HTML>
