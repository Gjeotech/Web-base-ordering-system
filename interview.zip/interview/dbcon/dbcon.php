<?php

$link = mysqli_connect("Localhost","root","","an_interview") or die ("Unable to connect");




?>