<?php 

include("../dbcon/dbcon.php");

$id = $_GET['DTHA'];

$del_smt = "DELETE FROM `oder_products` WHERE id ='$id'";
$run = mysqli_query($link, $del_smt);

if($run){
	header("Location: view_order.php");
	
}else{
	echo "<script>Alert('Error Deleting')</script>"; 
}


?>
