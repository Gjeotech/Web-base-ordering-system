<?php

include("../dbcon/dbcon.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>SuperFreighters</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<style>
th,td {
    border: 1px solid green;
	text-align:center;
}


#dex{
	
	width:250px;
	height:30px;
	
}


</style>


<style>
.css-serial {
counter-reset: serial-number;   /* Set the serial number counter to 0 */
  font-size:20px
  
}

.css-serial td:first-child:before {
counter-increment: serial-number;   /* Increment the serial number counter */
content: counter(serial-number);   /* Display the counter */
}


</style>




</head>
<body style="margin:0px">

<br><br><br><br><br><br>
<!--close-Header-part--> 
<div id="sidebar">
  <ul>
  
    <li class="active"><a href="acct_validate.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
          
    
  </ul>
</div>
<!--top-Header-menu-->



<div id="content">
  <div id="content-header">
  
    <div id="breadcrumb"> <a href="index.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> 
</div>

</div>

		<br>

<h2>VIEW ORDERED GOODS</h2>
<!--Action boxes-->
  <div class="container-fluid">
    <div class="quick-actions_homepage">			
<table class="css-serial">
  <thead>
    <tr>
      <th><h5 style="color:navy">S/N</h5></th>
	  <th><h5 style="color:navy">Email</h5></th>
	  <th><h5 style="color:navy">Product name</h5></th>
      <th><h5 style="color:navy">From</h5></th>
      <th><h5 style="color:navy">TO</h5></th> 
	  <th><h5 style="color:navy">Mode</h5></th>
      <th><h5 style="color:navy">Weight</h5></th>
      <th><h5 style="color:navy">Tax</h5></th> 
	  <th><h5 style="color:navy">Total charges</h5></th>
      <th><h5 style="color:navy">Date</h5></th>
      <th><h5 style="color:navy">Delete order</h5></th>
    </tr>
  </thead>
  <tbody style="width:100% overflow-y:auto">
  <?php
$total_chg2=0;

  $read = "SELECT * FROM oder_products ";
  $asses = mysqli_query($link,$read);
  while($row = mysqli_fetch_array($asses)){
  $id = $row['id'];
  $email = $row['user_email'];
  $prodt_name =$row['product_name'];
  $destn_cost =$row['Destination_cost'];
  $to_loc = (strtolower($row['To']));
  $mod_cost =$row['mode_cost'];
  $weight =$row['weight_kg'];
  $tax_add =$row['taxation_fee'];
  $total_chg =$row['total_charge'];
  $total_chg2 +=$row['total_charge'];
  $date = $row['Order_date'];
  
  //modify destination 
  $Destn = $destn_cost;
  if($destn_cost ==800){
	  $Destn = 'UK';
  }else if($Destn == 1500){
	  $Destn = 'US';
  }
  
  
  //modify mode of transportation
   $trsn_md = $mod_cost;
  if($trsn_md ==15000){
	  $trsn_md = 'By Sea';
	  
  }else if($trsn_md ==50000){
	  $trsn_md = 'By Air';
  }
   echo"
    <tr>
                  <td></td>
                  <td> $email</td>
				  <td style='text-align:center'>$prodt_name</td>
				  <td style='text-align:center'>$Destn</td>
                  <td>$to_loc</td>
				  <td style='text-align:center'>$trsn_md</td>
                  <td>$weight &#13199</td>
				  <td style='text-align:center'>$tax_add &#37</td>
                  <td>&#8358;".number_format($total_chg,2)."</td>
				   <td style='text-align:center'>$date </td>
				  <td style='text-align:center'><a href='delete_order.php?DTHA=$id'>DELETE</td>
				  
				  
    </tr>
	
  ";
  }
   ?>
  </tbody>
</table> 
<div style="background-color:red;width:150px;height:80px;color:white;font-weight:bold"><p>ALL TOTAL GRAND CHARGES</P>
<?php echo"<h3>&#8358;".number_format($total_chg2,2)."</h3>"; ?></div> 

<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_validation.js"></script>
</body>
</html>
